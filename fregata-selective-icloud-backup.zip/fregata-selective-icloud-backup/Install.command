#!/bin/bash
PACKAGE_DIR="$(cd "$(dirname "$0")" && pwd)"
"$PACKAGE_DIR/install.sh"
STATUS=$?
echo
if [ "$STATUS" -eq 0 ]; then
  echo "Installation finished. You can close this window."
else
  echo "Installation stopped. Read the message above, correct the configuration, then try again."
fi
read -r -p "Press Return to close this window. "
exit "$STATUS"
