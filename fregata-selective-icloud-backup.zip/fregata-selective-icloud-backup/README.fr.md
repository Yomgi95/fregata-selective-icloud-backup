# Sauvegarde sélective Fregata pour macOS

Ce projet répond à un besoin simple : conserver une copie hors du Mac des vidéos de surveillance qui comptent vraiment. Il sélectionne les événements détectés par Fregata comme **personne** (`person`) ou **voiture** (`car`), puis place leurs clips et les instantanés associés dans iCloud Drive. Ainsi, si le Mac est volé ou endommagé, les vidéos déjà synchronisées restent consultables depuis un autre appareil connecté au même compte iCloud.

Pour chaque événement, le script sur le Mac demande à Fregata de créer un clip unique à partir des petits segments vidéo enregistrés localement : le clip commence **30 secondes avant le début de l’événement** et se termine **60 secondes après sa fin**. Fregata rassemble ainsi les segments qui couvrent cette période en une vidéo plus facile à consulter. Le script copie ensuite ce clip, ainsi que les instantanés disponibles, vers le dossier iCloud Drive.

Ce paquet est conçu pour **l’application Fregata pour macOS**. Il n’est pas destiné à une installation Frigate classique sur une VM, un NAS, Docker ou un serveur Linux. Il ne supprime ni les enregistrements sources ni les copies de destination.

La copie iCloud est une protection contre la perte du Mac seulement une fois la synchronisation terminée. Le script écrit dans le dossier iCloud local et ne peut pas vérifier que l’envoi vers les serveurs Apple est achevé ; un événement tout récent pourrait donc ne pas encore être disponible dans le cloud.

Le clip est demandé à l’API Frigate pour la plage horaire configurée. L’adresse par défaut pointe vers Frigate sur la même machine. Garde cette API sur un réseau local de confiance ; le script ne gère pas l’authentification API.

## Prérequis

- Un Mac Apple Silicon avec Fregata installé, configuré et démarré.
- Python 3 sur le Mac.
- iCloud Drive activé si tu veux synchroniser les copies.
- Une rétention Fregata assez longue pour que le script récupère les vidéos. La base et les médias doivent rester accessibles sur ce Mac.

## Configuration

1. Vérifie que Fregata est ouvert et affiche l’état **Running** dans l’icône de la barre des menus. Termine son assistant et vérifie que tes caméras enregistrent. Dans le menu Fregata, active aussi **Settings → Launch at Login** pour que Fregata revienne après un redémarrage du Mac.
2. Télécharge ce paquet puis double-clique sur le ZIP pour le décompresser.
3. Ouvre le dossier décompressé et double-clique sur `Install.command`. Si macOS bloque le fichier, fais un clic droit dessus puis choisis **Ouvrir**.
4. Avec les emplacements Fregata par défaut, le programme trouve automatiquement `~/Fregata/config/frigate.db` et `~/Fregata/media`. Si tu as déplacé ces dossiers, une fenêtre te demandera de les choisir. Leurs emplacements sont visibles dans le menu Fregata → Settings → Folders.
5. Garde le dossier Frigate-Record proposé dans iCloud Drive, ou choisis un autre dossier existant. Vérifie qu’iCloud Drive est connecté ; Frigate-Record sera créé automatiquement.
6. Garde l’adresse proposée `http://127.0.0.1:5000`, sauf si tu as changé le port interne de Fregata.
7. Après vérification des chemins, l’installateur active les sauvegardes planifiées. Il ne reprend pas les événements antérieurs. Les nouveaux événements `person` et `car` sont traités toutes les deux minutes.
8. Pour vérifier, provoque un événement de test et cherche son dossier dans iCloud Drive → Frigate-Record. Le Mac doit rester allumé, ta session ouverte et Fregata en marche pour assembler les clips.

Si Python 3 manque, installe Python 3 pour macOS et relance `Install.command`. Si Fregata est arrêté ou si le Mac dort, l’assemblage attendra que l’application et le Mac soient de nouveau disponibles.

L’installateur crée un marqueur à l’installation. Seuls les événements démarrant après cette date seront traités ; il n’y a pas de reprise historique. Avant de charger la LaunchAgent, il vérifie la base, les dossiers, la destination et l’API.

## Résultat et fonctionnement

Les fichiers sont rangés ainsi :

    destination/AAAA-MM-JJ/caméra/identifiant/recordings/event.mp4

Les captures propres et miniatures disponibles vont dans le dossier snapshots de l’événement. Les événements en cours peuvent produire une vidéo mise à jour lorsque de nouveaux segments stables arrivent. Les événements terminés ne sont pas retraités si leur plage horaire n’a pas changé.

Le script écrit dans le dossier local de destination. Il ne peut pas confirmer que le fournisseur cloud a terminé la synchronisation à distance.

## Vérifier et lancer

Vérifier la configuration :

    python3 ~/Library/Application\ Support/FrigateSelectiveBackup/frigate_selective_backup.py --config ~/Library/Application\ Support/FrigateSelectiveBackup/config.json --check

Simuler un événement :

    python3 ~/Library/Application\ Support/FrigateSelectiveBackup/frigate_selective_backup.py --config ~/Library/Application\ Support/FrigateSelectiveBackup/config.json --dry-run --event-id IDENTIFIANT

Lire le journal :

    tail -n 20 ~/Library/Logs/FrigateSelectiveBackup.log

## Arrêter les exécutions planifiées

Lance :

    launchctl bootout gui/$(id -u)/org.frigate.selective-icloud-backup

Cela arrête la planification sans supprimer les vidéos.

## Confidentialité

Le projet ne contient aucune adresse de caméra, aucun nom de compte, mot de passe ou détail de réseau privé. La configuration et les journaux restent sur le Mac. Ne publie pas un vrai config.json ni les journaux sur un dépôt public.

## Licence

Distribué sous licence MIT. Voir le fichier LICENSE.
