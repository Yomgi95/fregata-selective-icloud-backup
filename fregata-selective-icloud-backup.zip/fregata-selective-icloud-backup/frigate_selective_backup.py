#!/usr/bin/env python3
"""Save one combined MP4 and event snapshots for selected Frigate labels."""

import argparse
import datetime as dt
import json
import os
from pathlib import Path
import shutil
import sqlite3
import sys
import tempfile
import time
from urllib.error import HTTPError, URLError
from urllib.parse import quote
from urllib.request import Request, urlopen


DEFAULT_CONFIG = Path.home() / "Library/Application Support/FrigateSelectiveBackup/config.json"


def expand_path(value):
    return Path(os.path.expandvars(str(value))).expanduser()


def load_config(path):
    with path.open("r", encoding="utf-8") as stream:
        config = json.load(stream)
    required = (
        "database_path", "media_root", "api_base_url", "destination", "labels",
        "pre_capture_seconds", "post_capture_seconds", "stable_seconds",
        "interval_seconds", "cutover_marker", "log_path",
    )
    missing = [key for key in required if key not in config]
    if missing:
        raise ValueError("Missing configuration keys: " + ", ".join(missing))
    if not isinstance(config["labels"], list) or not config["labels"]:
        raise ValueError("labels must be a non-empty JSON list")
    if any(not isinstance(label, str) or not label.strip() for label in config["labels"]):
        raise ValueError("each label must be a non-empty string")
    for key in ("pre_capture_seconds", "post_capture_seconds", "stable_seconds", "interval_seconds"):
        if float(config[key]) < 0:
            raise ValueError(key + " must be zero or greater")
    if float(config["interval_seconds"]) < 1:
        raise ValueError("interval_seconds must be at least 1")
    config["database_path"] = expand_path(config["database_path"])
    config["media_root"] = expand_path(config["media_root"])
    config["destination"] = expand_path(config["destination"])
    config["cutover_marker"] = expand_path(config["cutover_marker"])
    config["log_path"] = expand_path(config["log_path"])
    config["api_base_url"] = str(config["api_base_url"]).rstrip("/")
    return config


def validate_config(config):
    db = config["database_path"]
    media = config["media_root"]
    dest = config["destination"]
    marker = config["cutover_marker"]
    if not db.is_file():
        raise ValueError("Frigate database not found: " + str(db))
    if not media.is_dir():
        raise ValueError("Frigate media folder not found: " + str(media))
    if not dest.is_dir():
        raise ValueError("Destination folder must exist: " + str(dest))
    if not marker.is_file():
        raise ValueError("Cutover marker not found; run install.sh first: " + str(marker))
    request = Request(config["api_base_url"] + "/api/version", headers={"Accept": "*/*"})
    try:
        with urlopen(request, timeout=5) as response:
            if response.status != 200:
                raise ValueError("Frigate API returned status " + str(response.status))
    except (HTTPError, URLError, OSError) as exc:
        raise ValueError("Cannot reach Frigate API at " + config["api_base_url"] + ": " + str(exc)) from exc


def log(message, config, dry_run=False):
    stamp = dt.datetime.now().astimezone().isoformat(timespec="seconds")
    line = f"{stamp} {message}"
    print(line)
    if not dry_run:
        path = config["log_path"]
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as stream:
            stream.write(line + "\n")


def copy_snapshot(source, target, config, dry_run):
    try:
        stat = source.stat()
    except FileNotFoundError:
        return "missing"
    except OSError as exc:
        log(f"ERROR reading snapshot {source}: {exc}", config, dry_run)
        return "errors"
    if time.time() - stat.st_mtime < float(config["stable_seconds"]):
        return "unstable"
    try:
        if target.is_file():
            old = target.stat()
            if old.st_size == stat.st_size and old.st_mtime_ns == stat.st_mtime_ns:
                return "existing"
        if dry_run:
            log(f"DRY-RUN snapshot {source} -> {target}", config, dry_run)
            return "planned"
        target.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(prefix=".frigate-snapshot-", dir=target.parent, delete=False) as tmp:
            temp_name = tmp.name
        try:
            shutil.copy2(source, temp_name)
            if Path(temp_name).stat().st_size != stat.st_size:
                raise OSError("snapshot changed during copy")
            os.replace(temp_name, target)
        finally:
            try:
                Path(temp_name).unlink()
            except FileNotFoundError:
                pass
        log(f"SNAPSHOT {target}", config, dry_run)
        return "copied"
    except OSError as exc:
        log(f"ERROR snapshot copy {source}: {exc}", config, dry_run)
        return "errors"


def fetch_clip(camera, lower, upper, target, config, dry_run):
    base = config["api_base_url"]
    camera_part = quote(camera, safe="")
    url = f"{base}/api/{camera_part}/start/{lower:.6f}/end/{upper:.6f}/clip.mp4"
    if dry_run:
        log(f"DRY-RUN combined clip camera={camera} window={upper-lower:.1f}s -> {target}", config, dry_run)
        return True
    temp_name = None
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        request = Request(url, headers={"Accept": "video/mp4"})
        with urlopen(request, timeout=180) as response:
            content_type = response.headers.get_content_type()
            if response.status != 200 or content_type != "video/mp4":
                raise OSError(f"unexpected API response: status={response.status} type={content_type}")
            with tempfile.NamedTemporaryFile(prefix=".frigate-event-", suffix=".mp4", dir=target.parent, delete=False) as tmp:
                temp_name = tmp.name
                while True:
                    block = response.read(1024 * 1024)
                    if not block:
                        break
                    tmp.write(block)
        if Path(temp_name).stat().st_size < 1024:
            raise OSError("Frigate returned an empty clip")
        os.replace(temp_name, target)
        log(f"CLIP {target} window={upper-lower:.1f}s size={target.stat().st_size}", config, dry_run)
        return True
    except (HTTPError, URLError, OSError) as exc:
        log(f"ERROR Frigate clip camera={camera} window={lower:.3f}-{upper:.3f}: {exc}", config, dry_run)
        if temp_name:
            try:
                Path(temp_name).unlink()
            except OSError:
                pass
        return False


def write_state(path, signature):
    temp_name = None
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", prefix=".clip-state-", dir=path.parent, delete=False) as tmp:
            temp_name = tmp.name
            json.dump(signature, tmp, sort_keys=True)
            tmp.write("\n")
        os.replace(temp_name, path)
        return True
    except OSError:
        if temp_name:
            try:
                Path(temp_name).unlink()
            except OSError:
                pass
        return False


def process(config, dry_run=False, event_id=None):
    marker = config["cutover_marker"]
    cutover_time = float(marker.read_text(encoding="utf-8").strip())
    now = time.time()
    labels = config["labels"]
    placeholders = ",".join("?" for _ in labels)
    uri = config["database_path"].resolve().as_uri() + "?mode=ro"
    totals = {key: 0 for key in (
        "clips_created", "clips_unchanged", "clips_planned", "snapshots_copied",
        "snapshots_existing", "snapshots_planned", "missing_snapshots", "delayed", "errors",
    )}
    with sqlite3.connect(uri, uri=True, timeout=5) as con:
        con.row_factory = sqlite3.Row
        sql = (
            "SELECT id,label,camera,start_time,end_time,has_snapshot FROM event "
            f"WHERE label IN ({placeholders}) "
        )
        params = list(labels)
        if event_id:
            sql += "AND id=? "
            params.append(event_id)
        else:
            sql += "AND start_time>=? "
            params.append(cutover_time)
        sql += "ORDER BY start_time"
        events = con.execute(sql, params).fetchall()
        for event in events:
            event_name = str(event["id"])
            camera_name = str(event["camera"])
            if any(sep in event_name or sep in camera_name for sep in ("/", "\\")) or event_name in (".", "..") or camera_name in (".", ".."):
                log(f"ERROR refusing unsafe event path: camera={camera_name} event={event_name}", config, dry_run)
                totals["errors"] += 1
                continue
            start = float(event["start_time"])
            end = float(event["end_time"]) if event["end_time"] is not None else None
            lower = start - float(config["pre_capture_seconds"])
            if end is None:
                upper = now - float(config["stable_seconds"])
            else:
                upper = end + float(config["post_capture_seconds"])
                if now < upper + float(config["stable_seconds"]):
                    totals["delayed"] += 1
                    continue
            if upper <= lower:
                totals["delayed"] += 1
                continue
            date_dir = dt.datetime.fromtimestamp(start).astimezone().strftime("%Y-%m-%d")
            event_dir = config["destination"] / date_dir / camera_name / event_name
            video_path = event_dir / "recordings" / "event.mp4"
            state_path = event_dir / "recordings" / ".clip-state.json"
            signature = {"lower": round(lower, 3), "upper": round(upper, 3)}
            previous = None
            try:
                if state_path.is_file():
                    previous = json.loads(state_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                previous = None
            if video_path.is_file() and previous == signature:
                totals["clips_unchanged"] += 1
            elif fetch_clip(camera_name, lower, upper, video_path, config, dry_run):
                if dry_run:
                    totals["clips_planned"] += 1
                elif write_state(state_path, signature):
                    totals["clips_created"] += 1
                else:
                    totals["errors"] += 1
            else:
                totals["errors"] += 1
            if event["has_snapshot"]:
                sources = (
                    config["media_root"] / "clips" / f"{camera_name}-{event_name}-clean.webp",
                    config["media_root"] / "clips" / "thumbs" / camera_name / f"{event_name}.webp",
                )
                for source in sources:
                    result = copy_snapshot(source, event_dir / "snapshots" / source.name, config, dry_run)
                    if result == "copied":
                        totals["snapshots_copied"] += 1
                    elif result == "existing":
                        totals["snapshots_existing"] += 1
                    elif result == "missing":
                        totals["missing_snapshots"] += 1
                    elif result == "errors":
                        totals["errors"] += 1
                    elif result == "planned":
                        totals["snapshots_planned"] += 1
                    elif result == "unstable":
                        totals["delayed"] += 1
    log(
        f"SUMMARY events={len(events)} clips_created={totals['clips_created']} "
        f"clips_unchanged={totals['clips_unchanged']} clips_planned={totals['clips_planned']} "
        f"snapshots_copied={totals['snapshots_copied']} snapshots_planned={totals['snapshots_planned']} "
        f"snapshots_existing={totals['snapshots_existing']} missing_snapshots={totals['missing_snapshots']} "
        f"delayed={totals['delayed']} errors={totals['errors']} mode={'dry-run' if dry_run else 'copy'}",
        config,
        dry_run,
    )
    return 1 if totals["errors"] else 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--check", action="store_true", help="validate configuration and local Frigate access")
    parser.add_argument("--dry-run", action="store_true", help="show planned actions without writing media")
    parser.add_argument("--event-id", help="process one event ID for a manual validation")
    args = parser.parse_args()
    try:
        config = load_config(args.config.expanduser())
        validate_config(config)
        if args.check:
            print("Configuration, Frigate database/media, destination, and API are reachable.")
            return 0
        return process(config, dry_run=args.dry_run, event_id=args.event_id)
    except (OSError, ValueError, sqlite3.Error) as exc:
        print("ERROR: " + str(exc), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
