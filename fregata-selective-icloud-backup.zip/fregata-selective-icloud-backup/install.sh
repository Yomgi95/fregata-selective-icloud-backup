#!/bin/bash
set -euo pipefail

APP_NAME="FrigateSelectiveBackup"
LABEL="org.frigate.selective-icloud-backup"
APP_DIR="$HOME/Library/Application Support/$APP_NAME"
LAUNCH_AGENTS_DIR="$HOME/Library/LaunchAgents"
CONFIG="$APP_DIR/config.json"
SCRIPT="$APP_DIR/frigate_selective_backup.py"
CONFIGURATOR="$APP_DIR/configure.py"
MARKER="$APP_DIR/cutover.txt"
PLIST="$LAUNCH_AGENTS_DIR/$LABEL.plist"
PACKAGE_DIR="$(cd "$(dirname "$0")" && pwd)"
PYTHON_BIN="$(command -v python3 || true)"

if [ -z "$PYTHON_BIN" ]; then
  echo "Python 3 is required."
  exit 1
fi
if launchctl print "gui/$(id -u)/$LABEL" >/dev/null 2>&1; then
  echo "The LaunchAgent $LABEL is already loaded. Unload it before reinstalling."
  exit 1
fi

mkdir -p "$APP_DIR" "$LAUNCH_AGENTS_DIR" "$HOME/Library/Logs"
install -m 755 "$PACKAGE_DIR/frigate_selective_backup.py" "$SCRIPT"
if [ ! -f "$CONFIG" ]; then
  cp "$PACKAGE_DIR/config.example.json" "$CONFIG"
  install -m 755 "$PACKAGE_DIR/configure.py" "$CONFIGURATOR"
  if ! "$PYTHON_BIN" "$CONFIGURATOR" "$CONFIG"; then
    rm -f "$CONFIG"
    exit 1
  fi
fi

if [ ! -f "$MARKER" ]; then
  "$PYTHON_BIN" -c 'import time; print(f"{time.time():.6f}")' > "$MARKER"
fi

"$PYTHON_BIN" - "$CONFIG" <<'PY'
import json, os, sys
from pathlib import Path
config = json.load(open(sys.argv[1], encoding="utf-8"))
destination = Path(os.path.expandvars(config["destination"])).expanduser()
destination.mkdir(parents=True, exist_ok=True)
PY

"$PYTHON_BIN" "$SCRIPT" --config "$CONFIG" --check

if [ -e "$PLIST" ]; then
  cp -p "$PLIST" "$PLIST.backup-$(date +%Y%m%d-%H%M%S)"
fi
"$PYTHON_BIN" - "$PLIST" "$SCRIPT" "$CONFIG" "$PYTHON_BIN" "$LABEL" <<'PY'
import os, plistlib, sys, tempfile, json
plist_path, script_path, config_path, python_path, label = sys.argv[1:]
with open(config_path, encoding="utf-8") as stream:
    interval = int(json.load(stream)["interval_seconds"])
data = {
    "Label": label,
    "ProgramArguments": [python_path, script_path, "--config", config_path],
    "StartInterval": interval,
    "RunAtLoad": True,
    "StandardOutPath": os.path.expanduser("~/Library/Logs/FrigateSelectiveBackup-output.log"),
    "StandardErrorPath": os.path.expanduser("~/Library/Logs/FrigateSelectiveBackup-error.log"),
}
fd, temp_path = tempfile.mkstemp(prefix=".frigate-selective-", dir=os.path.dirname(plist_path))
try:
    with os.fdopen(fd, "wb") as stream:
        plistlib.dump(data, stream, sort_keys=False)
    os.chmod(temp_path, 0o644)
    os.replace(temp_path, plist_path)
except Exception:
    try: os.unlink(temp_path)
    except OSError: pass
    raise
PY

launchctl bootstrap "gui/$(id -u)" "$PLIST"
echo "Installed. Runs at login and every configured interval."
echo "Configuration: $CONFIG"
echo "Log: $HOME/Library/Logs/FrigateSelectiveBackup.log"
