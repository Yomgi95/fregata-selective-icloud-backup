#!/usr/bin/env python3
"""First-run macOS path picker for the Frigate backup installer."""

import json
import subprocess
import sys
from pathlib import Path


def apple_script(script):
    result = subprocess.run(
        ["/usr/bin/osascript", "-e", script],
        check=True, capture_output=True, text=True,
    )
    return result.stdout.strip()


def choose_file(prompt):
    return Path(apple_script(f'POSIX path of (choose file with prompt "{prompt}")'))


def choose_folder(prompt):
    return Path(apple_script(f'POSIX path of (choose folder with prompt "{prompt}")'))


def main():
    config_path = Path(sys.argv[1]).expanduser()
    config = json.loads(config_path.read_text(encoding="utf-8"))
    default_database = Path.home() / "Fregata/config/frigate.db"
    default_media = Path.home() / "Fregata/media"
    if default_database.is_file():
        config["database_path"] = str(default_database)
    else:
        print("Fregata's database is not at its default location. Select it in the Finder window.")
        config["database_path"] = str(choose_file(
            "Sélectionnez frigate.db / Select the database. Fregata default: ~/Fregata/config/frigate.db"
        ))
    if default_media.is_dir():
        config["media_root"] = str(default_media)
    else:
        print("Fregata's media folder is not at its default location. Select it in the Finder window.")
        config["media_root"] = str(choose_folder(
            "Sélectionnez le dossier média / Select media folder. Fregata default: ~/Fregata/media"
        ))

    apple_script(
        'display dialog '
        '"Configuration Fregata détectée : base de données et médias sur ce Mac. / '
        'Fregata configuration detected: database and media are on this Mac." '
        'buttons {"Continuer / Continue"} default button "Continuer / Continue"'
    )

    choice = apple_script(
        'button returned of (display dialog '
        '"Utiliser le dossier Frigate-Record dans iCloud Drive ? Il sera créé automatiquement. / '
        'Use the default Frigate-Record folder in iCloud Drive? It will be created automatically." '
        'buttons {"Choisir un autre dossier / Choose another folder", "Utiliser iCloud / Use iCloud Drive"} '
        'default button "Utiliser iCloud / Use iCloud Drive")'
    )
    if choice.startswith("Choisir un autre dossier"):
        config["destination"] = str(choose_folder("Sélectionnez un dossier existant / Select an existing destination folder"))

    api = apple_script(
        'text returned of (display dialog '
        '"Adresse de l’API Frigate (souvent http://127.0.0.1:5000). Si Frigate tourne sur un autre ordinateur, entrez son adresse locale. / '
        'Frigate API address (usually http://127.0.0.1:5000). If it runs on another computer, enter its local address." '
        'default answer "http://127.0.0.1:5000" buttons {"Annuler / Cancel", "Continuer / Continue"} '
        'default button "Continuer / Continue")'
    )
    config["api_base_url"] = api.rstrip("/")
    config_path.write_text(json.dumps(config, indent=2) + "\n", encoding="utf-8")
    print(f"Configuration saved: {config_path}")


if __name__ == "__main__":
    try:
        main()
    except subprocess.CalledProcessError:
        print("Setup was cancelled or a Mac file picker could not open. Run install.sh again to retry.", file=sys.stderr)
        sys.exit(1)
